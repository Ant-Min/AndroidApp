package com.example.minunniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class EventsGrid extends AppCompatActivity {

    static HashMap<String, String> events = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_grid);

        ListView eventView = (ListView) findViewById(R.id.listView);

        events.put("Kyle's Birthday", "April 5, 2022 @ 12:00 AM");
        events.put("Graduation", "May 22, 2022 @ 11:00 AM");
        events.put("Suzie's Recital", "June 3, 2022 @ 8:00 PM");

        List<HashMap<String, String>> listEvents = new ArrayList<>();
        SimpleAdapter adapter = new SimpleAdapter(this, listEvents,
                R.layout.list_item, new String[]{"First Line", "Second Line"},
                new int[]{R.id.text1, R.id.text2});

        Iterator it = events.entrySet().iterator();

        while(it.hasNext()){
            HashMap<String, String> results = new HashMap<>();
            Map.Entry pair = (Map.Entry)it.next();
            results.put("First Line", pair.getKey().toString());
            results.put("Second Line", pair.getValue().toString());
            listEvents.add(results);
        }

        eventView.setAdapter(adapter);

        eventView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                openAddEvent();
            }
        });
    }

    public void openAddEvent() {
        Intent intent = new Intent(this, AddEvent.class);
        startActivity(intent);
    }
}