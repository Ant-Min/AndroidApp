package com.example.minunniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddEvent extends AppCompatActivity {

    private EditText eventName;
    private EditText eventDate;
    private EditText eventTime;
    private Button addEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        eventName = findViewById(R.id.event_name);
        eventDate = findViewById(R.id.event_date);
        eventTime = findViewById(R.id.event_time);
        addEvent = findViewById(R.id.add_event);

    }

    public void AddEvent(View view){
        String event = eventName.getText().toString();
        String date = eventDate.getText().toString();
        String time = eventTime.getText().toString();
        if(event == null || date == null || time == null){
            eventName.setText("");
            eventDate.setText("");
            eventTime.setText("");
        }
        else{
            EventsGrid.events.put(event, date + " " + time);
            openEventsGrid();
        }
    }

    public void openEventsGrid() {
        Intent intent = new Intent(this, EventsGrid.class);
        startActivity(intent);
    }
}